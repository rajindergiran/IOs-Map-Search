//
//  ViewController.swift
//  mapSearch
//
//  Created by rajinder giran on 2017-11-15.
//  Copyright © 2017 rajindergiran. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation



class ViewController: UIViewController , CLLocationManagerDelegate {
    
    
    @IBOutlet weak var searchBox: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        let manager = CLLocationManager()
        manager.delegate = self
        manager.requestWhenInUseAuthorization()
        
        //search
        let x = searchBox.text!
        print(x)
        let searchrequest = MKLocalSearchRequest()
        searchrequest.naturalLanguageQuery = x
        let abc = MKLocalSearch(request: searchrequest)
        abc.start { (response, error) in
            //type code
            if response == nil{
                print("no result")
            }
            else{
                print(response)
            }
        }
    }
    
    
    
    
}

